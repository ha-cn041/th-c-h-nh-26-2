
const questions = [
 
        // Câu hỏi đúng/sai
    {
      question: "HTML là ngôn ngữ lập trình để tạo trang web.",
      options: ["Đúng", "Sai"],
      answer: true
    },
    {
        question: "Logo của đội bóng Chelsea là con sư tử?",
        options: ["Đúng", "Sai"],
        answer: true
    },
    {
        question: "Khỉ là loài vật đầu tiên bay vào không gian ngoài con người?",
        options: ["Đúng", "Sai"],
        answer: false,
    },
    {
        question: "Châu Phi là lục địa duy nhất nằm ở cả 4 bán cầu?",
        options: ["Đúng", "Sai"],
        answer: true,  
    },
    {
        question: "Frankenstein là một con quái vật được tạo ra bởi một nhà khoa học điên?",
        options: ["Đúng", "Sai"],
        answer: false,  
    },
    {
        question: "Louis Braille là người đã tạo ra hệ thống chữ nổi cho người mù, chính ông cũng bị mù?",
        options: ["Đúng", "Sai"],
        answer: true,
    },
    {
        question: "1 con bạch tuộc có 7 trái tim?",
        options: ["Đúng", "Sai"],
        answer: false,
    },
    {
        question: "Có một nguyên tố hoá học được gọi là americium, được đặt tên theo châu Mỹ?",
        options: ["Đúng", "Sai"],
        answer: true,
    },
    { 
        question: "Dơi bị mù?",
        options: ["Đúng", "Sai"],
        answer: false,
    },
    {
        question: "Đại Tây Dương là đại dương sâu nhất thế giới?",
        options: ["Đúng", "Sai"],
        answer: false,
    },
    // Câu hỏi chọn 1 trong 4
    {
      type: "single-choice",
      question: "CSS dùng để làm gì?",
      answers: [
        "Tạo bố cục trang web",
        "Thêm hiệu ứng cho trang web",
        "Xử lý dữ liệu",
        "Tất cả các đáp án trên",
      ],
      answer: 0,
    },
    {
        question: "Quốc gia nào sau đây có hơn 10.000 bãi biển?",
        answers: [
            "Úc", "Anh","Pháp","Italia",
        ],
        answer: 0,
      },
      {
        question: "Hòn đảo xinh đẹp có con đường trên biển độc đáo tên là gì?",
        answers: [
          "đảo nam du","đảo điệp sơn","đảo bình ba","đảo cái hải"
        ],
        answer: 1,
      },
      {
        question: "Những vòng tròn vuông góc với kinh tuyến trên quả Địa Cầu là:",
        answers: [
          "kinh tuyến"," kinh tuyến gốc","vĩ tuyến","vĩ tuyến gốc",
        ],
        answer: 2,
      },
      {
        question: "Vào buổi sáng, chúng ta thấy Mặt Trời mọc ở",
        answers: [
          "hướng đông","hướng tây","hướng nam","hướng bắc",
        ],
        answer: 0,
      },
      {
        question: "Sự bùng nổ dân số diễn ra vào năm",
        answers: [
          "1500","1804","1972","1950",
        ],
        answer: 3,
      },
      {
        question: "Năm 2001 dân số thế giới khoảng",
        answers: [
          "4 tỉ","5 tỉ","6,16 tỉ","6,5 tỉ",
        ],
        answer: 2,
      },
      
      {
        question: "Sự bùng nổ dân số đang diễn ra ở các châu lục nào dưới đây?",
        answers: [
            "Châu Đại Dương","Bắc Mĩ","Châu Âu","Nam Mĩ",
        ],
        answer: 3,
      },
      {
        question: "Châu Á không tiếp giáp đại dương nào sau đây?",
        answers: [
          "Thái Bình Dương"," Đại Tây Dương","Ấn Độ Dương","Bắc Băng Dương",
        ],
        answer: 1,
      },
      {
        question: "Việt Nam là một quốc gia có nhiều dân tộc, có tất cả",
        answers: [
          "52","53","54","55",
        ],
        answer: 2,
      },
];

const quizContainer = document.getElementById('quiz-container');
const questionElement = document.getElementById('question');
const optionsElement = document.getElementById('options');
const resultElement = document.getElementById('result');
const submitButton = document.getElementById('submit-btn');

let currentQuestionIndex = 0;
let score = 0;

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    optionsElement.innerHTML = "";
    currentQuestion.options.forEach(option => {
        const button = document.createElement('button');
        button.textContent = option;
        button.addEventListener('click', () => selectAnswer(option));
        optionsElement.appendChild(button);
    });
}

function selectAnswer(selectedOption) {
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedOption === currentQuestion.answer) {
        score++;
    }
}

function showResult() {
    resultElement.textContent = `Điểm của bạn là ${score}/${questions.length}`;
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        quizContainer.innerHTML = "";
        showResult();
    }
}

submitButton.addEventListener('click', nextQuestion);

showQuestion();

